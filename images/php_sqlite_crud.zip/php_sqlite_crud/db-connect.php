<?php
if(!is_dir('./db'))
    mkdir('./db');
if(!defined('db_file')) define('db_file','./db/dummy_db.db');
function my_udf_md5($string) {
    return md5($string);
}

Class Database extends SQLite3{
    private $allowed_field;
    function __construct(){
         $this->open(db_file);
         $this->exec("PRAGMA foreign_keys = ON;");
         $this->exec("CREATE TABLE IF NOT EXISTS `member_list` (
            `ID` INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT,
            `fullname` INTEGER NOT NULL,
            `email` TEXT NOT NULL,
            `contact` TEXT NOT NULL,
            `address` TEXT NOT NULL,
            `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            `updated_at` TIMESTAMP DEFAULT NULL
        )"); 
        $this->allowed_field = ['ID', 'fullname', 'email', 'contact', 'address'];
        $this->exec("CREATE TRIGGER IF NOT EXISTS member_updated_at AFTER UPDATE on `member_list`
        BEGIN
            UPDATE `member_list` SET `updated_at` = CURRENT_TIMESTAMP where ID = ID;
        END
        ");
    }
    function __destruct(){
         $this->close();
    }
    function sanitize_string($string = ""){
        if(!is_numeric($string)){
            $string = addslashes($this->escapeString($string));
        }
        return $string;
    }
    public function insert($data = []){
        if(!is_array($data)){
            return ['status' => 'failed', "error" => "Data must be an array."];
        }else{
            if(count($data) <= 0)
            return ['status' => 'failed', "error" => "Data is empty"];

            $fields = "";
            $values = "";
            foreach($data as $k => $v){
                if(in_array($k, $this->allowed_field) && $k != "ID"){
                    $v = $this->sanitize_string($v);
                    if(!empty($fields)) $fields .= ", ";
                    $fields .= "`{$k}`";
                    if(!empty($values)) $values .= ", ";
                    $values .= "'{$v}'";
                }
            }
            if(empty($fields))
            return ['status' => 'failed', "error" => "Given data fields are not allowed"];
            
            $sql = "INSERT INTO `member_list` ({$fields}) VALUES ({$values})";
            $save = $this->query($sql);
            if($save){
                return ['status' => 'success'];
            }else{
                return ['status' => 'failed', "error" => $this->lastErrorMsg()];
            }
        }
    }

    public function get_results(){
        $sql = "SELECT * FROM `member_list` order by ID asc";
        $query = $this->query($sql);
        $data = [];
        while($row = $query->fetchArray()){
            $data[] = $row;
        }
        return ['num_rows' => count($data), 'data' => $data];
    }
    public function get_single_by_id($id){
        $id = $this->sanitize_string($id);
        $sql = "SELECT * FROM `member_list` where `ID` = '{$id}'";
        $query = $this->query($sql);
        return $query->fetchArray();
    }

    public function update($data=[]){
        if(!is_array($data)){
            return ['status' => 'failed', "error" => "Data must be an array."];
        }else{
            if(count($data) <= 0)
            return ['status' => 'failed', "error" => "Data is empty"];

            $update_data = "";
            foreach($data as $k => $v){
                if(in_array($k, $this->allowed_field) && $k != "ID"){
                    $v = $this->sanitize_string($v);
                    if(!empty($update_data)) $update_data .= ", ";
                    $update_data .= "`{$k}`= '{$v}'";
                }
            }
            if(empty($update_data))
            return ['status' => 'failed', "error" => "Given data fields are not allowed"];
            $id = $this->sanitize_string($data['id']);
            $sql = "UPDATE `member_list` set {$update_data} where ID = '{$id}'";
            $save = $this->query($sql);
            if($save){
                return ['status' => 'success'];
            }else{
                return ['status' => 'failed', "error" => $this->lastErrorMsg()];
            }
        }
    }
    public function delete($id=""){
        if(empty($id))
        return ['status' => 'failed', "error" => "ID is required."];
        if(!is_numeric($id))
        return ['status' => 'failed', "error" => "ID cannot be a string."];
        $sql = "DELETE FROM `member_list` where `ID` = '{$id}'";
        $delete = $this->query($sql);
        if($delete){
            return ['status' => 'success'];
        }else{
            return ['status' => 'failed', "error" => $this->lastErrorMsg()];
        }
        
    }
}
