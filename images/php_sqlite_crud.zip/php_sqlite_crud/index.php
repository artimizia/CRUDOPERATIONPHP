<?php
require_once("functions.php");
if($_SERVER['REQUEST_METHOD'] == "POST"){
    if(empty($_POST['id'])){
       $action->insert_member(); 
    }else{
       $action->update_member(); 

    }
}
if(isset($_GET['action'])){
    switch($_GET['action']){
        case 'edit':
            $data = $action->get_member_by_id($_GET['id']);
            break;
        case 'delete':
            $data = $action->delete_member($_GET['id']);
            break;
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>CRUD using PHP and SQLite</title>
    <!-- Fontawsome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.2.0/css/all.min.css" integrity="sha512-xh6O/CkQoPOWDdYTDqeRdPCVd1SpvCA9XXcUnZS2FmJNp1coAFzvtCN9BmamE+4aHK8yyUHUSCcJHgXloTyT2A==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <script src="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.2.0/js/all.min.js" integrity="sha512-naukR7I+Nk6gp7p5TMA4ycgfxaZBJ7MO5iC3Fp6ySQyKFHOGfpkSZkYVWV5R7u7cfAicxanwYQ5D1e17EfJcMA==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.2/dist/css/bootstrap.min.css" integrity="sha384-Zenh87qX5JnK2Jl0vWa8Ck2rdkQ2Bzep5IDxbcnCeuOxjzrPF/et3URy9Bv1WTRi" crossorigin="anonymous">
    <!-- jQuery -->
    <script src="https://code.jquery.com/jquery-3.6.1.min.js" integrity="sha256-o88AwQnZB+VDvE9tvIXrMQaPlFFSUTR+nldQm1LuPXQ=" crossorigin="anonymous"></script>
    <!-- Bootstrap Bundle JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-OERcA2EqjJCMA+/3y+gxIOqMEjwtxJY7qPCqsdltbNJuaOe923+mo//f6V8Qbsw3" crossorigin="anonymous"></script>
    <style>
        html,body{
            height:100%;
            width:100%;
        }
       
    </style>
</head>
<body>
    <main>
        <nav class="navbar navbar-expand-lg navbar-dark bg-primary bg-gradient">
            <div class="container">
                <a class="navbar-brand" href="#">
                CRUD using PHP and SQLite
                </a>
                <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
                </button>
                <div class="collapse navbar-collapse" id="navbarNav">
                    <ul class="navbar-nav">
                        <li class="nav-item">
                            <a class="nav-link" aria-current="page" href="./">Home</a>
                        </li>
                    </ul>
                </div>
                <div>
                    <a href="https://sourcecodester.com" class="text-decoration-none text-light fw-bold">SourceCodester</a>
                </div>
            </div>
        </nav>
        <div class="container my-3 py-2">
            <div class="row">
                <div class="col-lg-5 col-md-6 col-sm-12">
                    <div class="card rounded-0 shadow">
                        <div class="card-header">
                            <div class="card-title"><b>Form Panel</b></div>
                        </div>
                        <div class="card-body rounded-0">
                            <div class="container-fluid">
                                <form id="sample-form" action="" method="POST">
                                    <?php if(isset($_SESSION['form_error_msg'])): ?>
                                        <div class="alert alert-danger rounded-0">
                                            <?= $_SESSION['form_error_msg'] ?>
                                        </div>
                                    <?php unset($_SESSION['form_error_msg']); ?>
                                    <?php endif; ?>
                                    <input type="hidden" name="id" value="<?= isset($data['ID']) ? $data['ID'] : '' ?>">
                                    <div class="mb-3">
                                        <label for="fullname" class="control-label fw-bold">Fullname</label>
                                        <input type="text" class="form-control rounded-0" id="fullname" name="fullname" value="<?= isset($data['fullname']) ? $data['fullname'] : '' ?>" required="required">
                                    </div>
                                    <div class="mb-3">
                                        <label for="email" class="control-label fw-bold">Email</label>
                                        <input type="email" class="form-control rounded-0" id="email" name="email" value="<?= isset($data['email']) ? $data['email'] : '' ?>" required="required">
                                    </div>
                                    <div class="mb-3">
                                        <label for="contact" class="control-label fw-bold">Contact</label>
                                        <input type="text" class="form-control rounded-0" id="contact" name="contact" value="<?= isset($data['contact']) ? $data['contact'] : '' ?>" required="required">
                                    </div>
                                    <div class="mb-3">
                                        <label for="address" class="control-label fw-bold">Address</label>
                                        <textarea rows="3" class="form-control rounded-0" id="address" name="address" required="required"><?= isset($data['address']) ? $data['address'] : '' ?></textarea>
                                    </div>
                                </form>
                            </div>
                        </div>
                        <div class="card-header rounded-0 py-2">
                            <div class="d-flex justify-content-center">
                                <button class="btn btn-primary btn-sm rounded-0 mx-1" form="sample-form"><i class="fa fa-save"></i> Save</button>
                                <button class="btn btn-sm rounded-0 btn-default border border-dark mx-1" id="reset-form" type="button"><i class="fa fa-times"></i> Cancel</button>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-lg-7 col-md-6 col-sm-12">
                    <?php if(isset($_SESSION['success_msg'])): ?>
                        <div class="alert alert-success rounded-0">
                            <?= $_SESSION['success_msg'] ?>
                        </div>
                    <?php unset($_SESSION['success_msg']); ?>
                    <?php endif; ?>
                    <?php if(isset($_SESSION['error_msg'])): ?>
                        <div class="alert alert-danger rounded-0">
                            <?= $_SESSION['error_msg'] ?>
                        </div>
                    <?php unset($_SESSION['error_msg']); ?>
                    <?php endif; ?>

                    <div class="card shadow rounded-0">
                        <div class="card-header">
                            <div class="card-title"><b>Member Lists</b></div>
                        </div>
                        <div class="card-body">
                            <div class="container-fluid">
                                <table class="table table-bordered table-hover table-striped">
                                    <colgroup>
                                        <col width="5%">
                                        <col width="20%">
                                        <col width="15%">
                                        <col width="15%">
                                        <col width="30%">
                                        <col width="15%">
                                    </colgroup>
                                    <thead>
                                        <tr class="bg-primary text-light">
                                            <th class="text-center">#</th>
                                            <th class="text-center">Name</th>
                                            <th class="text-center">Email</th>
                                            <th class="text-center">Contact</th>
                                            <th class="text-center">Address</th>
                                            <th class="text-center">Action</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php
                                        $members = $action->member_list();
                                        ?>
                                        <?php if($members['num_rows'] > 0): ?>
                                            <?php foreach($members['data'] as $row): ?>
                                                <tr>
                                                    <th class="text-center"><?= $row['ID'] ?></th>
                                                    <td class="p-1"><?= $row['fullname'] ?></td>
                                                    <td class="p-1"><?= $row['email'] ?></td>
                                                    <td class="p-1"><?= $row['contact'] ?></td>
                                                    <td class="p-1"><?= $row['address'] ?></td>
                                                    <td class="p-1 text-center">
                                                        <a href="./?action=edit&id=<?= $row['ID'] ?>" class="btn btn-sm btn-outline-primary"><i class="fa fa-edit" title="Edit Member"></i></a>
                                                        <a href="./?action=delete&id=<?= $row['ID'] ?>" class="btn btn-sm btn-outline-danger" onclick="if(confirm(`Are you sure to delete this member?`) === false) event.preventDefault();"><i class="fa fa-trash" title="Delete Member"></i></a>
                                                    </td>
                                                </tr>
                                            <?php endforeach; ?>
                                        <?php else: ?>
                                            <tr>
                                                <th class="text-center p-1" colspan="6">No result</th>
                                            </tr>
                                        <?php endif; ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </main>
</body>
<script>
    $(document).ready(function(){
        $('#reset-form').click(function(e){
            e.preventDefault()
            if($("[name='id']").val() !== ""){
                location.replace("./")
            }
            $('#sample-form')[0].reset()
        })
    })
</script>
</html>